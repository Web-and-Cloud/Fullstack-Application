<?php

// include __DIR__ . '/src/Database.php';
include __DIR__ . '/vendor/autoload.php';

use App\Database;

$db = new Database();

$sqlFile = file_get_contents("./database.sql");

$db->query($sqlFile);

