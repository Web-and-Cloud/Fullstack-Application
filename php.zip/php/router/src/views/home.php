

<?php include "./inc/_header.php"; ?>

<h1><?= $title; ?></h1>

<?php include "./inc/_footer.php"; ?>

