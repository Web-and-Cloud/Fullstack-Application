<?php

declare(strict_types=1);

namespace App\Controllers;

use App\TemplateEngine;
use App\Config\Paths;
use App\Models\UserModel;
use App\Session;

class UserController 
{

  private TemplateEngine $view;
  private UserModel $userModel;

  public function __construct()
  {
    $this->view = new TemplateEngine(Paths::VIEW);
    $this->userModel = new UserModel();
  }

  public function login()
  {
    echo 'login page';

    // tarkistettu käyttäjän kirjautusmistiedot
    // ok
    Session::start();
    Session::set('userID', 1);
    Session::set('userName', 'Matti Meikäläinen');

    $userID = Session::get('userID');
  }

  public function register()
  {
    if ($_SERVER['REQUEST_METHOD'] === 'POST'){
      
      //luetaan lomakkeen tiedot data-muuttujaan
      $data = [
        'name' => trim($_POST['name']),
        'email' => trim($_POST['email']),
        'password' => trim($_POST['password'])
      ];

      $this->userModel->createUser($data);

      header("Location: /login");

    }else {
      echo $this->view->render("/users/register.php");
    }
  }

  public function logout()
  {
    Session::destroy();
  }
  
}