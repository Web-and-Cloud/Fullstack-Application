<?php

declare(strict_types=1);

namespace App\Models;

use App\Database;

class UserModel 
{
  private Database $db;

  public function __construct()
  {
    $this->db = new Database();
  }

  public function isEmailTaken(string $email)
  {
    $emailCount = $this->db->query(
      "SELECT COUNT(*) 
       FROM users 
       WHERE email = :email",
      [
        'email' => $email
      ]
    )->count();

    if($emailCount > 0){
      echo 'Et voi käyttää kyseistä sähköpostia';
    }
  }

  public function createUser(array $formData)
  {
    
    $this->db->query(
      "INSERT INTO users (name, email, password)
       VALUES (:name, :email, :password)",
       [
        'email' => $formData['email'],
        'name' => $formData['name'],
        'password'=>  password_hash($formData['password'], PASSWORD_BCRYPT, ['cost' => 12])
       ]
    );

  }

  public function login(array $formData)
  {

  }

  public function logout()
  {
    
  }

}