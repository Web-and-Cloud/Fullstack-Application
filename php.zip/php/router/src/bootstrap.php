<?php

declare(strict_types=1);

require_once __DIR__ . "/../vendor/autoload.php";

use App\App;
use App\Controllers\HomeController;
use App\Controllers\UserController;

$app = new App();

$app->get('/', [HomeController::class, 'home']);
$app->get('/about', [HomeController::class, 'about']);

$app->get('/register', [UserController::class, 'register'] );
$app->post('/register', [UserController::class, 'register'] );

$app->get('/login', [UserController::class, 'login'] );
$app->post('/login', [UserController::class, 'login'] );

return $app;