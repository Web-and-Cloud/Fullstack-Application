CREATE TABLE posts_2 (
  postID int NOT NULL PRIMARY KEY AUTO_INCREMENT,
  userID int NOT NULL,
  title varchar(100) NOT NULL,
  body text NOT NULL,
  created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
);