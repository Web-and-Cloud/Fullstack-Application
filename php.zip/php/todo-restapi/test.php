public function getTodos() {
    // määritetään headers tiedot
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Methods: GET");
    header("Content-Type: application/json; charset=UTF-8");

    if ($_SERVER['REQUEST_METHOD'] == 'GET') {
        // Check if 'title' is provided in the GET request
        if (isset($_GET['title'])) {
            $title = $_GET['title'];
        } else {
            $title = null; // Or handle as needed
        }

        $todos = $this->todo->getAll();
        echo json_encode($todos);
    } else {
        http_response_code(405);
        echo json_encode(['error' => 'Method not allowed']);
    }
}
