<?php

namespace App\Models;

use App\Database;

class Todo{
    private $db;

    public function __construct(){
        $this->db = (new Database())->getConnection();
    }

    public function create($title){
        $stmt = $this->db->prepare("INSERT INTO
                todos (title) VALUES (:title)");

        $stmt ->bindParam(':title' , $title);
        return $stmt->execute(); 

    }

    public function getAll(){
        $stmt = $this->db->prepare("SELECT * FROM todos");
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function update($id, $title){
        $stmt = $this->db->prepare("UPDATE todos 
                                    SET title = :title 
                                    WHERE id = :id"); 
        //binding parameters
        $stmt -> bindParam(':title', $title);
        $stmt -> bindParam(':id', $id);
        return $stmt->execute();

    }

    public function delete($id){
        $stmt = $this->db->prepare("DELETE FROM todos WHERE id = :id");

        $stmt->bindParam(':id', $id);
        return $stmt->execute();


    }
}