<?php

namespace App\Controllers;

use App\Models\Todo;

class TodoController {
    private $todo;

    public function __construct(){
        $this->todo = new Todo();
    }

    public function createTodo(){

        //määritetään headers tiedot

        header("Access-Control-Allow-Origin: *");
        header("Access-Control-Allow-Methods: GET");
        header("Content-Type: application/json; charset=UTF-8");


        if($_SERVER['REQUEST_METHOD'] =='POST'){
            $title = $_POST['title'];
            $this->todo->create($title);
            http_response_code(201);
            echo json_encode(['message' => 'Todo created']);
        }else {
            http_response_code(405); 
            echo json_encode(['error' => 'Method not allowed']);
        }
    }

    public function getTodos() {

        //määritetään headers tiedot

        header("Access-Control-Allow-Origin: *");
        header("Access-Control-Allow-Methods: GET");
        header("Content-Type: application/json; charset=UTF-8");

        if($_SERVER['REQUEST_METHOD'] =='GET'){
           
            if (isset($_GET['title'])) {
                $title = $_GET['title'];
            } else {
                $title = null; 
            }
        $todos = $this->todo->getAll();
        echo json_encode($todos);
        }else {
            http_response_code(405); 
            echo json_encode(['error' => 'Method not allowed']);
        }
    }

    
    public function updateTodos() {

        //määritetään headers tiedot

        header("Access-Control-Allow-Origin: *");
        header("Access-Control-Allow-Methods: PUT");
        header("Content-Type: application/json; charset=UTF-8");

        if($_SERVER['REQUEST_METHOD'] =='PUT'){
            parse_str(file_get_contents('php://input'), $put_vars);
            $title = $put_vars['title'];
            $id = $put_vars['id'];
        $todos = $this->todo->update($id, $title);
        echo json_encode(['message' => 'Todo updated']);
        }else {
            http_response_code(405); 
            echo json_encode(['error' => 'Method not allowed']);
        }
    }

    public function deleteTodos() {

        //määritetään headers tiedot

        header("Access-Control-Allow-Origin: *");
        header("Access-Control-Allow-Methods: GET");
        header("Content-Type: application/json; charset=UTF-8");

        if($_SERVER['REQUEST_METHOD'] =='DELETE'){
            parse_str(file_get_contents('php://input'), $delete_vars);
            
            $id = $delete_vars['id'];
        $todos = $this->todo->delete($id);
        echo json_encode(['message' => 'Todo deleted']);
    }else {
        http_response_code(405); 
        echo json_encode(['error' => 'Method not allowed']);
    }
}
}
        