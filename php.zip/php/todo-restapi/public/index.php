<?php

require_once __DIR__ . '/../vendor/autoload.php';

use Dotenv\Dotenv;
use App\Controllers\TodoController;

$dotenv = Dotenv::createImmutable(__DIR__ . '/../');
$dotenv->load();

// Simple routing based on the request method and URI
$controller = new TodoController();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $controller->getTodos();
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $controller->createTodo();
} else {
    http_response_code(404);
    echo json_encode(['message' => 'Not Found']);
}
