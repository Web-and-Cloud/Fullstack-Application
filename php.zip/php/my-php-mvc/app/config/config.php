<?php
//1.These constants hold the connection details for a MySQL database,
// typically used for interacting with the database in a PHP application.
define('DB_HOST', 'localhost');
define('DB_USER', 'my-php-mvc');
define('DB_PASS', 'my-php-mvc');
define('DB_NAME', 'my-php-mvc');

//2. App Root Constant
define('APPROOT', dirname(dirname(__FILE__)));

//3. URL Root Constant
define('URLROOT', 'http://localhost/my-php-mvc');

//4. Site Name Constant
define('SITENAME', 'MY-PHP-MVC');

//password database: UBbNvu!sjV2tNGCg