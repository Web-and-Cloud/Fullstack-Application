<?php

declare(strict_types=1);

namespace App;

class TemplateEngine
{
    public function __construct(private string $basepath)
    {

    }

    public function render(string $template, array $data= [])
    {
        $data['engine'] = $this;
        extract($data, EXTR_SKIP);
        ob_start();

        include $this->resolve($template);

        $output = ob_get_contents();

        ob_end_clean();

        return $output;
    }

    public function resolve(string $path)
    {
        return "{$this->basepath}/{$path}";
    }
}
