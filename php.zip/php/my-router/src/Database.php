<?php

// import phpdotenv using $ composer require vlucas/phpdotenv

namespace App;

use PDO, PDOStatement, PDOException;

use Dotenv\Dotenv;

class Database{
    private PDO $connection;
    private PDOStatement $stmt;

    public function __construct()
    {
        $dotenv = Dotenv::createImmutable(__DIR__."/../");
        $dotenv->load();

        $dns = "mysql:host=" . $_ENV['DB_HOST'] . ";dbname=" . $_ENV['DB_NAME'];
        $username = $_ENV['DB_USER'];
        $password = $_ENV['DB_PASSWORD'];

        try {
            $this->connection = new PDO($dns, $username, $password,
            [
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
            ]);
        } catch(PDOException $e) {
            die("Tietokantaan ei saada yhteytta");
        }
    }

    public function getConnection(){
        return $this->connection;
    }

    public function query(string $query, array $params = []):Database
    {
        $this->stmt = $this->connection->prepare($query);
        $this->stmt->execute($params);

        return $this;
    }

    public function count()
    {
        return $this->stmt->fetchColumn();
    }

    public function find()
    {
        return $this->stmt->fetch();
    }

    public function id()
    {
        return $this->connection->lastInsertId();
    }


}