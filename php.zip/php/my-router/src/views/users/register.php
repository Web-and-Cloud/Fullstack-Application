<?php include $engine->resolve("inc/_header.php");?>

<div class="row">
<div class="col-md-8 mx-auto">
    <h2 class="mb-3">
        Create New User
    </h2>

    <form action="" method="post">

    <div class="row mb-3">
        <label for="name" class="col-sm-3 col-form-label">Name</label>
        <div class="col-sm-9">
            <input 
            value="<?= $data['name'] ?? '';?>"
            name="name"
            type="text"
            class="form-control <?= (!empty($data['name_err'])) ? 'is-invalid' : ''; ?> ">
            <?php if(!empty($data['name_err'])): ?>
              <div class="invalid-feedback">
                <small><?= $data['name_err']; ?></small>
              </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="row mb-3">
        <label for="email" class="col-sm-3 col-form-label">Emailmail</label>
        <div class="col-sm-9">
            <input 
            value="<?= $data['email'] ?? '';?>"
            name="email"
            type="text"
            class="form-control <?= (!empty($data['email_err'])) ? 'is-invalid' : ''; ?> ">
            <?php if(!empty($data['email_err'])): ?>
              <div class="invalid-feedback">
                <small><?= $data['email_err']; ?></small>
              </div>
            <?php endif; ?>
        </div>
    </div>

            <div class="row mb-3">
                <label for="password" class="com-sm-3 col-form-label">Password</label>
                <div class="col-sm-9">
                    <input name="password" type="password" class="form-control">
                </div>
            </div>

            <div class="row mb-3">
                <label for="confirm_password" class="com-sm-3 col-form-label"> Confirm Password</label>
                <div class="col-sm-9">
                    <input name="confirm_password" type="confirm_password" class="form-control">
                </div>
            </div>

            <button class="btn btn-primary" type="submit" >Submit</button>

    </form>
</div>
</div>

<?php include $engine->resolve("inc/_footer.php");?>