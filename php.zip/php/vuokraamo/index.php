<?php
  include_once 'inc/header.php';
?>
    
  <div class="container">
    <h1>Tervetuloa SSKKY-vuokraamoon!</h1>
  </div>

<?php
  include_once 'inc/footer.php';
?>