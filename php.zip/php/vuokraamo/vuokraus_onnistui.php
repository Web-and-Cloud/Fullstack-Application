<?php
include_once 'inc/header.php'
?>
<div class="container">
    <h3>Vuokraus Onnistui</h3>
    </div>
<?php
include_once 'inc/footer.php'
?>