<?php
// tietokannan yhteystiedot
define('DB_HOST', 'localhost');
define('DB_USER', 'php-mvc');
define('DB_PASS', 'php-mvc');
define('DB_NAME', 'php-mvc');

//sovelluksen juurihakemisto
define('APPROOT', dirname(dirname(__FILE__)));

// urlin juuri
define('URLROOT', 'http://localhost/php-mvc');

// sivuston nimi
define('SITENAME', 'PHP-MVC');