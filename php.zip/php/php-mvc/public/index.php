<?php

require_once '../app/loader.php';

//alustetaan Core
$init = new Core();