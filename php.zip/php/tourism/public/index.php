<?php

require_once __DIR__ . '/../vendor/autoload.php';

use App\Router;
use App\Controller\Customer;
use Dotenv\Dotenv;

// Load environment variables from .env file
$dotenv = Dotenv::createImmutable(__DIR__ . '/../');
$dotenv->load();

// Initialize the router
$router = new Router();

// Define routes with their corresponding controllers and methods
$router->get('/customers', [Customer::class, 'getCustomers']);
$router->get('/customer/{ID}', [Customer::class, 'getCustomer']);

$router->post('/customers', [Customer::class, 'addCustomer']);
$router->put('/customers/{ID}', [Customer::class, 'updateCustomer']);
$router->delete('/customers/{ID}', [Customer::class, 'deleteCustomer']);

// Run the router to match the request and invoke the appropriate controller
$router->run();
