<?php

namespace App;

use PDO, PDOException;

class Database{
    private PDO $pdo;

    public function __construct()
    {
        try{
            $dsn = "mysql:host=" . $_ENV['DB_HOST'] . ";dbname=" . $_ENV['DB_NAME'];
        } catch(PDOException $e){
            die("Database is not connected.");
        }
    }

    public function getConnection(){
        return $this->pdo;
    }
}