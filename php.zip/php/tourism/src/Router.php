<?php

namespace App;

class Router 
{
    private array $routes = [];

    private const METHOD_GET = 'GET';
    private const METHOD_POST = 'POST';
    private const METHOD_PUT = 'PUT';
    private const METHOD_DELETE = 'DELETE';

    public function get(string $path, callable|array $callback): void
    {
        $this->addRoute(self::METHOD_GET, $path, $callback);
    }

    public function post(string $path, callable|array $callback): void
    {
        $this->addRoute(self::METHOD_POST, $path, $callback);
    }

    public function put(string $path, callable|array $callback): void
    {
        $this->addRoute(self::METHOD_PUT, $path, $callback);
    }

    public function delete(string $path, callable|array $callback): void
    {
        $this->addRoute(self::METHOD_DELETE, $path, $callback);
    }

    private function addRoute(string $method, string $path, callable|array $callback): void
    {
        $param = $this->hasDynamicParams($path);

        $this->routes[] = [
            'path' => $path,
            'method' => $method,
            'param' => $param,
            'callback' => $callback,
        ];
    }

    
    private function hasDynamicParams(string $path): bool
    {
        return (bool) preg_match("/\{.*\}$/", $path);
    }

    public function run(): void
    {
        $uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        $method = $_SERVER['REQUEST_METHOD'];
        $params = array_merge($_GET, $_POST);

        $route = $this->matchRoute($uri, $method);

        if (!$route) {
            $this->handleNotFound();
            return;
        }

        $callback = $route['callback'];

        if ($route['param']) {
            $params = $this->extractParams($route['path'], $uri);
        }

        $this->executeCallback($callback, $params);
    }

    
    private function matchRoute(string $uri, string $method): ?array
    {
        foreach ($this->routes as $route) {
            if ($route['method'] === $method && $this->matchUri($route['path'], $uri)) {
                return $route;
            }
        }
        return null;
    }

        private function matchUri(string $routePath, string $requestPath): bool
    {
        // Strip out the dynamic parameter part for matching
        $routeRegex = preg_replace("/{.*}/", '', $routePath);
        $requestRegex = preg_replace("/[0-9]+/", '', $requestPath);
        return $routeRegex === $requestRegex;
    }

    
    private function extractParams(string $routePath, string $uri): array
    {
        preg_match_all("/(?<={).+?(?=})/", $routePath, $paramKeys);
        preg_match_all("/[0-9]+$/", $uri, $paramValues);

        if (empty($paramKeys) || empty($paramValues)) {
            return [];
        }

        return array_combine($paramKeys[0], $paramValues[0]);
    }

   
    private function executeCallback(callable|array $callback, array $params): void
    {
        if (is_array($callback)) {
            [$class, $method] = $callback;
            $object = new $class;
            $callback = [$object, $method];
        }

        call_user_func($callback, $params);
    }

    
    private function handleNotFound(): void
    {
        http_response_code(404);
        echo "404 - Page Not Found";
    }
}
