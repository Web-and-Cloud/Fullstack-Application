<?php

namespace App\Model;

use App\Database;
use PDO;

class Customer {

    private PDO $db;
    public function __construct()
    {
        $this->db = (new Database())->getConnection();
    }

    public function addCustomer(mixed $data){
       // bindparams

       $sql ="INSERT INTO asiakas
                (etinimi, sukunimi, sahkoposti, 
                lahiosoite, puhelinnumero,
                postitoimipaikka, puhelin, henkilotunnus)
                VALUES
                (?,?,?,?,?,?,?,?)";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute(array($data->etinimi, $data->sukunimi, $data->sahkoposti,
         $data->lahiosoite, $data->puhelinnumero,
        $data->postitoimipaikka, $data->puhelin, $data->henkilotunnus));
    }

    public function getCustomers(){

        $sql = "SELECT *
                FROM asiakas";

        $stmt = $this->db->prepare($sql);
        $stmt->execute();

        $customers= $stmt->fetchAll(PDO::FETCH_ASSOC);

        return json_encode($customers);

    }

    public function getCustomer($id){
        $sql = "SELECT *
                FROM asiakas
                WHERE asiakasID = :asiakasID";

        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(':asiakasID', $id);
        $stmt->execute();

        if($stmt->rowCount()=== 1){
            $customer = $stmt->fetch(PDO::FETCH_ASSOC);

            return json_encode($customer);

        }else{

            return json_encode(array("viesti" => "Asiakastietoa ei voida palauttaa"));
        }

    }

    public function updateCustomer(array $data){
        $sql = "UPDATE asiakas
                SET etunimi = :etunimi,
                    sukunimi = :sukunimi,
                    sahkoposti = :sahkoposti,
                    lahiosoite = :lahiosoite,
                    puhelinnumero = :puhelinnumero,
                    postitoimipaikka = :postitoimipaikka,
                    puhelin = :puhelin,
                    henkilotunnus = :henkilotunnus
                WHERE asiakasID = :asiakasID";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(':asiakasID', $data['asiakasID']);
        $stmt->bindParam(':etunimi', $data['etunimi']);
        $stmt->bindParam(':sukunimi', $data['sukunimi']);
        $stmt->bindParam(':sahkoposti', $data['sahkoposti']);
        $stmt->bindParam(':lahiosoite', $data['lahiosoite']);
        $stmt->bindParam(':puhelinnumero', $data['puhelinnumero']);
        $stmt->bindParam(':postitoimipaikka', $data['postitoimipaikka']);
        $stmt->bindParam(':puhelin', $data['puhelin']);
        $stmt->bindParam(':henkilotunnus', $data['henkilotunnus']);

        $stmt->execute();

        if($stmt->rowCount() > 0){
            $customer = $stmt->fetch(PDO::FETCH_ASSOC);

            return json_encode(array("viesti" => "Asiakastiedot päivittetty onnisteneest"));

        }else{

            return json_encode(array("viesti" => "Asiakastietoa eipäivittetty"));
        }

    }

    public function deleteCustomer($id){
        $sql = "DELETE FROM asiakas
                WHERE asiakasID = :asiakasID";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(':asiakasID', $id);
        $stmt->execute();

        if($stmt->rowCount() > 0){
            

            return json_encode(array("viesti" => "Asiakastiedon poistettu onnistuneesti"));

        }else{

            return json_encode(array("viesti" => "Asiakastietoa ei poistettu"));
        }

    }

    


}