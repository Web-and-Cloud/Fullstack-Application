<?php

namespace App\Controller;

use App\Model\Customer as CustomerModel;

class Customer
{

    private CustomerModel $customer;

    public function __construct()
    {
        $this->customer =new CustomerModel();
    }

    public function getCustomers(){
        //määritetään headers tiedot

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");
header("Content-Type: application/json; charset=UTF-8");

$customers = $this->customer->getCustomers();

http_response_code(200);
echo json_encode($customers);
       
}

public function getCustomer(array $params){
    //määritetään headers tiedot

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");
header("Content-Type: application/json; charset=UTF-8");

$customers = $this->customer->getCustomer($params['ID']);

http_response_code(200);
echo json_encode($customers);
   
}
    public function addCustomer(mixed $data){

        //määritetään headers tiedot

        header("Access-Control-Allow-Origin: *");
        header("Access-Control-Allow-Methods: GET");
        header("Content-Type: application/json; charset=UTF-8");

       if($this->customer->addCustomer($data)){
        http_response_code(201);
        echo json_encode([
            "viesti" =>"Asiakastiedot lisätty onnistuneesti"    
        ]);
        } else {
            http_response_code(503);
            echo json_encode([
            "viesti" =>"Asiakastietoja ei voitu tallentaa"    
        ]);
        };

      
   
    }

    public function updateCustomer(array $data){
        //määritetään headers tiedot

        header("Access-Control-Allow-Origin: *");
        header("Access-Control-Allow-Methods: PUT");
        header("Content-Type: application/json; charset=UTF-8");

        if($this->customer->updateCustomer($data)){
            http_response_code(200);
            echo json_encode(["viesti" => "Asiakastiedot päivitetty onnistuneesti"]);
        } else {
            http_response_code(503);
            echo json_encode(["viesti" => "Asiakastietoa ei voitu päivittetty."]);
        }

        
    }

    public function deleteCustomer(array $params){
        header("Access-Control-Allow-Origin: *");
        header("Access-Control-Allow-Methods: GET");
        header("Content-Type: application/json; charset=UTF-8");

        if($this->customer->deleteCustomer($params['id'])){
            http_response_code(200);
            echo json_encode(["viesti" => "Asiakastiedot poistettu onnistuneesti"]);
        } else {
            http_response_code(503);
            echo json_encode(["viesti" => "Asiakastietoa ei voitu poistettu."]);
        }
    }
}