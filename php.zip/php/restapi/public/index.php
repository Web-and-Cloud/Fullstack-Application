<?php

require_once __DIR__ . '/../vendor/autoload.php';

use App\Router;
use App\Controller\Customer;
use Dotenv\Dotenv;

$dotenv = Dotenv::createImmutable(__DIR__ . '/../');

$dotenv->load();

$router = new Router();

$router->get('/customers',[Customer::class, 'getCustomers']);
$router->get('/customer/{ID}', [Customer::class, 'getCustomer']);

$router->post('/customers', [Customer::class, 'addCustomer']);
$router->put('/customers/{ID}', [Customer::class, 'updateCustomer']);
$router->delete('/customers/{ID}', [Customer::class, 'deleteCustomer']);


// $router->get('/customers', function(){
//     echo 'customers';
// });


// $router->get('/customer/{ID}', function(array $params = []){
//     echo '$params['ID]';
// });




// $router->post('/customers', function(){
//     echo 'add customers';
// });


// $router->put('/customers/{ID}', function(array $params = []){
//     echo 'update customers ID:' . $params['ID'];
// });

// $router->delete('/customers/{ID}', function(array $params = []){
//     echo 'delete customers' . $params['ID'];
// });
$router->run();