<?php include "inc/_header.php"; ?>

<h1>Heats</h1>

<a href="/heats/create" class="btn btn-primary mb-3">Add New Heat</a>

<table class="table">
    <thead>
        <tr>
            <th>Name</th>
            <th>Date</th>
        </tr>
    </thead>
    <tbody>
        <?php if (!empty($heats)): ?>
            <?php foreach ($heats as $heat): ?>
                <tr>
                    <td><?= htmlspecialchars($heat['name']); ?></td>
                    <td><?= htmlspecialchars($heat['date']); ?></td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td colspan="2">No heats found</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>

<?php include "inc/_footer.php"; ?>
