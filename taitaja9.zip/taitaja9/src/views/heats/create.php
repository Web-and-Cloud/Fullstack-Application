<?php include "inc/_header.php"; ?>

<h1>Add New Heat</h1>

<form action="/heats/create" method="POST">
    <div class="mb-3">
        <label for="name" class="form-label">Heat Name</label>
        <input type="text" class="form-control <?= !empty($name_err) ? 'is-invalid' : ''; ?>" id="name" name="name" value="<?= htmlspecialchars($name ?? ''); ?>">
        <div class="invalid-feedback"><?= htmlspecialchars($name_err ?? ''); ?></div>
    </div>

    <div class="mb-3">
        <label for="date" class="form-label">Date</label>
        <input type="date" class="form-control <?= !empty($date_err) ? 'is-invalid' : ''; ?>" id="date" name="date" value="<?= htmlspecialchars($date ?? ''); ?>">
        <div class="invalid-feedback"><?= htmlspecialchars($date_err ?? ''); ?></div>
    </div>

    <button type="submit" class="btn btn-primary">Save</button>
</form>

<?php include "inc/_footer.php"; ?>
