<?php include "inc/_header.php"; ?>

<h1>Login</h1>

<form action="/login" method="POST">
    <div class="mb-3">
        <label for="team_name" class="form-label">Team Name</label>
        <input type="text" name="team_name" id="team_name" 
        class="form-control <?= (!empty($data['team_name_err'])) ? 'is-invalid' : ''; ?>" 
        value="<?= htmlspecialchars($data['team_name'] ?? ''); ?>">
        <div class="invalid-feedback"><?= htmlspecialchars($data['team_name_err'] ?? ''); ?></div>
    </div>

    <div class="mb-3">
        <label for="password" class="form-label">Password</label>
        <input type="password" name="password" id="password" 
        class="form-control <?= (!empty($data['password_err'])) ? 'is-invalid' : ''; ?>">
        <div class="invalid-feedback"><?= htmlspecialchars($data['password_err'] ?? ''); ?></div>
    </div>

    <button type="submit" class="btn btn-primary">Login</button>
</form>

<?php include "inc/_footer.php"; ?>
