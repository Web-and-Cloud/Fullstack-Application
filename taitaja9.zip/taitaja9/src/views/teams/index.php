<table>
    <thead>
        <tr>
            <th>Team Name</th>
            <th>School</th>
            <th>Members</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($teams as $team): ?>
            <tr>
                <td><?= htmlspecialchars($team['team_name']) ?></td>
                <td><?= htmlspecialchars($team['school']) ?></td>
                <td><?= htmlspecialchars($team['members']) ?></td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
