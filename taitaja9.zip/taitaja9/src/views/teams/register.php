<?php include "inc/_header.php"; ?>



<div class="row">
  <div class="col-md-8 mx-auto">
    <div class="card card-body bg-light mt-5">
      <h2 class="mb-3">Team Registration</h2>

      <form action="../Controllers/RegistrationController.php" method="POST">

      <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(Session::get('csrf_token')); ?>">

        
        <!-- Team Name -->
        <div class="row mb-3">
          <label for="team_name" class="col-sm-3 col-form-label">Team Name</label>
          <div class="col-sm-9">
            <input value="<?= $data['team_name'] ?? ''; ?>" 
            name="team_name" type="text" 
            class="form-control <?= (!empty($data['team_name_err'])) ? 'is-invalid' : ''; ?>" 
            id="team_name" required>
            <?php if (!empty($data['team_name_err'])): ?>
              <div class="invalid-feedback">
                <small><?= $data['team_name_err']; ?></small>
              </div>
            <?php endif; ?>
          </div>
        </div>

        <!-- School -->
        <div class="row mb-3">
          <label for="school" class="col-sm-3 col-form-label">School</label>
          <div class="col-sm-9">
            <input value="<?= $data['school'] ?? ''; ?>" 
            name="school" type="text" 
            class="form-control <?= (!empty($data['school_err'])) ? 'is-invalid' : ''; ?>" 
            id="school" required>
            <?php if (!empty($data['school_err'])): ?>
              <div class="invalid-feedback">
                <small><?= $data['school_err']; ?></small>
              </div>
            <?php endif; ?>
          </div>
        </div>

        <!-- Team Members -->
        <div class="row mb-3">
          <label for="members" class="col-sm-3 col-form-label">Team Members</label>
          <div class="col-sm-9">
            <textarea name="members" 
            class="form-control <?= (!empty($data['members_err'])) ? 'is-invalid' : ''; ?>" 
            id="members" rows="3" required><?= $data['members'] ?? ''; ?></textarea>
            <?php if (!empty($data['members_err'])): ?>
              <div class="invalid-feedback">
                <small><?= $data['members_err']; ?></small>
              </div>
            <?php endif; ?>
          </div>
        </div>

        <!-- Password -->
        <div class="row mb-3">
          <label for="password" class="col-sm-3 col-form-label">Password</label>
          <div class="col-sm-9">
            <input name="password" 
            type="password" 
            class="form-control <?= (!empty($data['password_err'])) ? 'is-invalid' : ''; ?>" 
            id="password" required>
            <?php if (!empty($data['password_err'])): ?>
              <div class="invalid-feedback">
                <small><?= $data['password_err']; ?></small>
              </div>
            <?php endif; ?>
          </div>
        </div>

        <!-- Confirm Password -->
        <div class="row mb-3">
          <label for="confirm_password" class="col-sm-3 col-form-label">Confirm Password</label>
          <div class="col-sm-9">
            <input name="confirm_password" 
            type="password" 
            class="form-control <?= (!empty($data['confirm_password_err'])) ? 'is-invalid' : ''; ?>" 
            id="confirm_password" required>
            <?php if (!empty($data['confirm_password_err'])): ?>
              <div class="invalid-feedback">
                <small><?= $data['confirm_password_err']; ?></small>
              </div>
            <?php endif; ?>
          </div>
        </div>

        <!-- Submit Button -->
        <button class="btn btn-primary" type="submit">Register</button>
      </form>
    </div>
  </div>
</div>






<?php include "inc/_footer.php"; ?>
