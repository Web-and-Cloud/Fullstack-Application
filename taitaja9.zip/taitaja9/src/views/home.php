<?php include "inc/_header.php"; ?>

<div class="container mt-5">
    <h1>Welcome to Taitaja9</h1>
    <p>This is the homepage of the Taitaja9 application. Navigate through the menu to explore the application.</p>
    
    <div class="row mt-4">
        <div class="col-md-4">
            <h3>User Login</h3>
            <p><a href="/users/login" class="btn btn-primary">Login as User</a></p>
        </div>
        <div class="col-md-4">
            <h3>Team Login</h3>
            <p><a href="/teams/login" class="btn btn-primary">Login as Team</a></p>
        </div>
        
    </div>
</div>

<?php include "inc/_footer.php"; ?>
