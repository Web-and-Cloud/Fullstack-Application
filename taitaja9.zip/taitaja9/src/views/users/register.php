<?php include "inc/_header.php"; ?>

<h1>User Registration</h1>
<form action="/register" method="POST">
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(Session::get('csrf_token')); ?>">

    <div>
        <label for="name">Name</label>
        <input type="text" id="name" name="name" value="<?= htmlspecialchars($data['name'] ?? ''); ?>">
        <span class="error"><?= htmlspecialchars($data['name_err'] ?? ''); ?></span>
    </div>

    <div>
        <label for="email">Email</label>
        <input type="email" id="email" name="email" value="<?= htmlspecialchars($data['email'] ?? ''); ?>">
        <span class="error"><?= htmlspecialchars($data['email_err'] ?? ''); ?></span>
    </div>

    <div>
        <label for="password">Password</label>
        <input type="password" id="password" name="password">
        <span class="error"><?= htmlspecialchars($data['password_err'] ?? ''); ?></span>
    </div>

    <div>
        <label for="confirm_password">Confirm Password</label>
        <input type="password" id="confirm_password" name="confirm_password">
        <span class="error"><?= htmlspecialchars($data['confirm_password_err'] ?? ''); ?></span>
    </div>

    <button type="submit">Register</button>
</form>

<?php include "inc/_footer.php"; ?>
