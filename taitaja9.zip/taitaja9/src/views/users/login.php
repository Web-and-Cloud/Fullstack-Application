<?php include "inc/_header.php"; ?>

<h1>User Login</h1>
<form action="/login" method="POST">
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(Session::get('csrf_token')); ?>">

    <div>
        <label for="email">Email</label>
        <input type="email" id="email" name="email" value="<?= htmlspecialchars($data['email'] ?? ''); ?>">
        <span class="error"><?= htmlspecialchars($data['email_err'] ?? ''); ?></span>
    </div>

    <div>
        <label for="password">Password</label>
        <input type="password" id="password" name="password">
        <span class="error"><?= htmlspecialchars($data['password_err'] ?? ''); ?></span>
    </div>

    <button type="submit">Login</button>
</form>

<?php include "inc/_footer.php"; ?>
