<?php include "inc/_header.php"; ?>

<h1>About Taitaja9</h1>
<p>
    Taitaja9 is a national skills competition designed for upper secondary schools in Finland. 
    The competition focuses on promoting vocational education and highlighting the importance of teamwork, 
    problem-solving, and creativity. Students participate in various heats and tasks to demonstrate their skills.
</p>

<p>
    For more information about the competition, please visit the official Taitaja9 website or contact us.
</p>

<?php include "inc/_footer.php"; ?>
