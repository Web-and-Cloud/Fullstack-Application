<?php include "inc/_header.php"; ?>

<h1>All Results</h1>
<table class="table">
    <thead>
        <tr>
            <th>Team Name</th>
            <th>Heat</th>
            <th>Time</th>
            <th>Rank</th>
            <th>Details</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($results as $result): ?>
            <tr>
                <td><?= htmlspecialchars($result['team_name']); ?></td>
                <td><?= htmlspecialchars($result['heat']); ?></td>
                <td><?= htmlspecialchars($result['time']); ?></td>
                <td><?= htmlspecialchars($result['rank']); ?></td>
                <td>
                    <a href="/results/<?= htmlspecialchars($result['id']); ?>">View Details</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<?php include "inc/_footer.php"; ?>
