<?php include "inc/_header.php"; ?>

<h1>Result Details</h1>

<p><strong>Team Name:</strong> <?= htmlspecialchars($result['team_name']); ?></p>
<p><strong>Heat:</strong> <?= htmlspecialchars($result['heat']); ?></p>
<p><strong>Time:</strong> <?= htmlspecialchars($result['time']); ?></p>
<p><strong>Rank:</strong> <?= htmlspecialchars($result['rank']); ?></p>

<h2>Breakdown</h2>
<ul>
    <?php foreach ($result['tasks'] as $task): ?>
        <li>
            <strong>Task <?= htmlspecialchars($task['task_number']); ?>:</strong> <?= htmlspecialchars($task['time']); ?> seconds
        </li>
    <?php endforeach; ?>
</ul>

<a href="/results">Back to All Results</a>

<?php include "inc/_footer.php"; ?>
