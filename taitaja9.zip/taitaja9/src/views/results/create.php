<?php include "inc/_header.php"; ?>

<h1>Add New Result</h1>

<form action="/results/create" method="POST">

    <!-- CSRF Token -->
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token ?? ''); ?>">

    <!-- Team ID -->
    <div class="mb-3">
        <label for="team_id" class="form-label">Team ID</label>
        <input 
            type="text" 
            class="form-control <?= !empty($team_id_err) ? 'is-invalid' : ''; ?>" 
            id="team_id" 
            name="team_id" 
            value="<?= htmlspecialchars($team_id ?? ''); ?>"
        >
        <?php if (!empty($team_id_err)): ?>
            <div class="invalid-feedback"><?= htmlspecialchars($team_id_err); ?></div>
        <?php endif; ?>
    </div>

    <!-- Heat ID -->
    <div class="mb-3">
        <label for="heat_id" class="form-label">Heat ID</label>
        <input 
            type="text" 
            class="form-control <?= !empty($heat_id_err) ? 'is-invalid' : ''; ?>" 
            id="heat_id" 
            name="heat_id" 
            value="<?= htmlspecialchars($heat_id ?? ''); ?>"
        >
        <?php if (!empty($heat_id_err)): ?>
            <div class="invalid-feedback"><?= htmlspecialchars($heat_id_err); ?></div>
        <?php endif; ?>
    </div>

    <!-- Score -->
    <div class="mb-3">
        <label for="score" class="form-label">Score</label>
        <input 
            type="text" 
            class="form-control <?= !empty($score_err) ? 'is-invalid' : ''; ?>" 
            id="score" 
            name="score" 
            value="<?= htmlspecialchars($score ?? ''); ?>"
        >
        <?php if (!empty($score_err)): ?>
            <div class="invalid-feedback"><?= htmlspecialchars($score_err); ?></div>
        <?php endif; ?>
    </div>

    <!-- Submit Button -->
    <button type="submit" class="btn btn-primary">Add Result</button>

</form>

<?php include "inc/_footer.php"; ?>
