<?php

declare(strict_types=1);

namespace App\Controllers;

use App\TemplateEngine;
use App\Config\Paths;
use App\Models\TeamModel;
use App\Session;

class TeamController
{
    private TemplateEngine $view;
    private TeamModel $teamModel;

    public function __construct()
    {
        $this->view = new TemplateEngine(Paths::VIEW);
        $this->teamModel = new TeamModel();
    }

    public function login()
    {
        Session::start();

        $data = [
            'team_name' => '',
            'password' => '',
            'team_name_err' => '',
            'password_err' => ''
        ];

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data['team_name'] = trim($_POST['team_name']);
            $data['password'] = trim($_POST['password']);

            if (empty($data['team_name'])) {
                $data['team_name_err'] = 'Team name is required';
            }

            if (empty($data['password'])) {
                $data['password_err'] = 'Password is required';
            }

            if (empty($data['team_name_err']) && empty($data['password_err'])) {
                $team = $this->teamModel->findTeamByName($data['team_name']);

                if ($team && password_verify($data['password'], $team['password'])) {
                    Session::set('team_id', $team['id']);
                    Session::set('team_name', $team['team_name']);

                    header('Location: /team-dashboard');
                    exit;
                } else {
                    $data['password_err'] = 'Invalid team name or password';
                }
            }
        }

        echo $this->view->render('teams/login.php', $data);
    }

    public function index(): void
{
    $db = new Database();

    
    $teams = $db->fetchAll("SELECT * FROM teams");

   
    echo $this->view->render('teams/index.php', ['teams' => $teams]);
}

}
