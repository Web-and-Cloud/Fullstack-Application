<?php

declare(strict_types=1);

namespace App\Controllers;

use App\TemplateEngine;
use App\Config\Paths;
use App\Models\HeatModel;

class HeatController
{
    private TemplateEngine $view;
    private HeatModel $heatModel;

    public function __construct()
    {
        $this->view = new TemplateEngine(Paths::VIEW);
        $this->heatModel = new HeatModel();
    }

    
    public function index(): void
    {
        $heats = $this->heatModel->getAllHeats();

        echo $this->view->render('heats/index.php', ['heats' => $heats]);
    }

    
    public function create(): void
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = [
                'name' => trim($_POST['name']),
                'date' => trim($_POST['date']),
                'name_err' => '',
                'date_err' => ''
            ];

            
            if (empty($data['name'])) {
                $data['name_err'] = 'Heat name is required';
            }

            if (empty($data['date'])) {
                $data['date_err'] = 'Heat date is required';
            }

            
            if (empty($data['name_err']) && empty($data['date_err'])) {
                $this->heatModel->createHeat($data);

               
                header('Location: /heats');
                exit;
            }

            echo $this->view->render('heats/create.php', $data);
        } else {
            echo $this->view->render('heats/create.php', [
                'name' => '',
                'date' => ''
            ]);
        }
    }
}
