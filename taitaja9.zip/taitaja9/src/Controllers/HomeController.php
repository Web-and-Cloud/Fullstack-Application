<?php

declare(strict_types=1);

namespace App\Controllers;

use App\TemplateEngine;
use App\Config\Paths;

class HomeController
{
    private TemplateEngine $view;

    public function __construct()
    {
        $this->view = new TemplateEngine(Paths::VIEW);
    }

    
    public function home(): void
    {
        $data = [
            'title' => 'Welcome to Taitaja9',
            'description' => 'A platform for managing Taitaja9 competition events.'
        ];

        echo $this->view->render('home.php', $data);
    }

    
    public function about(): void
    {
        $data = [
            'title' => 'About Taitaja9',
            'description' => 'Taitaja9 is a skills competition for schools.'
        ];

        echo $this->view->render('about.php', $data);
    }
}
