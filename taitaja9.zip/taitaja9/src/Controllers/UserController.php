<?php

declare(strict_types=1);

namespace App\Controllers;

use App\TemplateEngine;
use App\Config\Paths;
use App\Models\UserModel;
use App\Session;

class UserController
{
    private TemplateEngine $view;
    private UserModel $userModel;

    public function __construct()
    {
        $this->view = new TemplateEngine(Paths::VIEW);
        $this->userModel = new UserModel();
    }

    

    
    public function login()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Handle login form submission
            $data = [
                'email' => trim($_POST['email']),
                'password' => trim($_POST['password']),
                'email_err' => '',
                'password_err' => ''
            ];
    
            
            if (empty($data['email'])) {
                $data['email_err'] = 'Please enter your email';
            }
    
            
            if (empty($data['password'])) {
                $data['password_err'] = 'Please enter your password';
            }
    
            
            if (empty($data['email_err']) && empty($data['password_err'])) {
                
                $user = $this->userModel->getUserByEmail($data['email']);
                if ($user && password_verify($data['password'], $user['password'])) {
                    Session::start();
                    Session::set('user_id', $user['id']);
                    Session::set('user_name', $user['name']);
                    header('Location: /dashboard');
                    exit;
                } else {
                    $data['password_err'] = 'Invalid credentials';
                }
            }
    
            
            echo $this->view->render('users/login.php', $data);
        } else {
            
            echo $this->view->render('users/login.php', [
                'email' => '',
                'password' => '',
                'email_err' => '',
                'password_err' => ''
            ]);
        }
    }
    

    
    public function logout()
    {
        Session::start();
        Session::destroy();
        header('Location: /login');
        exit;
    }
}
