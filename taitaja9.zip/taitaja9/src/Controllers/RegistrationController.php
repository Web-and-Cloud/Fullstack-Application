<?php

declare(strict_types=1);

namespace App\Controllers;

use App\TemplateEngine;
use App\Config\Paths;
use App\Models\UserModel;
use App\Session;

class UserController
{
    private TemplateEngine $view;
    private UserModel $userModel;

    public function __construct()
    {
        $this->view = new TemplateEngine(Paths::VIEW);
        $this->userModel = new UserModel();
    }

    public function register()
    {
        Session::start(); 

        if (Session::get('csrf_token') === null) {
            Session::set('csrf_token', bin2hex(random_bytes(32)));
        }

        $data = [
            'team_name' => '',
            'school' => '',
            'members' => '',
            'password' => '',
            'confirm_password' => '',
            'team_name_err' => '',
            'school_err' => '',
            'members_err' => '',
            'password_err' => '',
            'confirm_password_err' => '',
            'csrf_token' => Session::get('csrf_token')
        ];

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Validate CSRF token
            if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== Session::get('csrf_token')) {
                http_response_code(403);
                die('Invalid CSRF token');
            }

            // Read form inputs
            $data['team_name'] = trim($_POST['team_name']);
            $data['school'] = trim($_POST['school']);
            $data['members'] = trim($_POST['members']);
            $data['password'] = trim($_POST['password']);
            $data['confirm_password'] = trim($_POST['confirm_password']);

            // Validate inputs
            if (empty($data['team_name'])) {
                $data['team_name_err'] = 'Team name is required';
            } elseif (!preg_match('/^[a-zA-Z0-9 ]+$/', $data['team_name'])) {
                $data['team_name_err'] = 'Team name can only contain letters, numbers, and spaces';
            }

            if (empty($data['school'])) {
                $data['school_err'] = 'School is required';
            }

            if (empty($data['members'])) {
                $data['members_err'] = 'Team members are required';
            }

            if (empty($data['password'])) {
                $data['password_err'] = 'Password is required';
            } elseif (strlen($data['password']) < 6) {
                $data['password_err'] = 'Password must be at least 6 characters';
            }

            if ($data['password'] !== $data['confirm_password']) {
                $data['confirm_password_err'] = 'Passwords do not match';
            }

            // If no errors, save the team to the database
            if (empty($data['team_name_err']) && empty($data['school_err']) &&
                empty($data['members_err']) && empty($data['password_err']) &&
                empty($data['confirm_password_err'])) {

                $hashed_password = password_hash($data['password'], PASSWORD_DEFAULT);

                $result = $this->userModel->createUser([
                    'team_name' => $data['team_name'],
                    'school' => $data['school'],
                    'members' => $data['members'],
                    'password' => $hashed_password
                ]);

                if (!$result) {
                    die('Failed to save the team to the database. Please try again.');
                }

                // Add success message and redirect to login
                Session::set('flash', 'Registration successful. Please log in.');
                header('Location: /login');
                exit;
            }
        }

        // Render the registration form
        echo $this->view->render('users/register.php', $data);
    }

    public function store(): void
{
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $db = new Database();

        // Insert team data into the database
        $db->query(
            "INSERT INTO teams (team_name, school, members, password) 
            VALUES (:team_name, :school, :members, :password)",
            [
                'team_name' => $_POST['team_name'],
                'school' => $_POST['school'],
                'members' => $_POST['members'],
                'password' => password_hash($_POST['password'], PASSWORD_BCRYPT)
            ]
        );

        
        header('Location: /teams');
        exit;
    }

    
    echo $this->view->render('teams/register.php');
}

}
