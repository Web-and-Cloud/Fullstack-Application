<?php

declare(strict_types=1);

namespace App\Controllers;

use App\TemplateEngine;
use App\Config\Paths;
use App\Models\ResultModel;
use App\Session;

class ResultsController
{
    private TemplateEngine $view;
    private ResultModel $resultModel;

    public function __construct()
    {
        $this->view = new TemplateEngine(Paths::VIEW);
        $this->resultModel = new ResultModel();
    }

    
    public function index(): void
    {
        $results = $this->resultModel->getAllResults();
        echo $this->view->render('results/index.php', ['results' => $results]);
    }

    
    public function show(int $id): void
    {
        $result = $this->resultModel->getResultById($id);
        if (!$result) {
            http_response_code(404);
            echo "Result not found";
            return;
        }
        echo $this->view->render('results/show.php', ['result' => $result]);
    }

    
    public function create(): void
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = [
                'team_id' => trim($_POST['team_id']),
                'heat_id' => trim($_POST['heat_id']),
                'score' => trim($_POST['score']),
                'csrf_token' => $_POST['csrf_token'] ?? '',
                'team_id_err' => '',
                'heat_id_err' => '',
                'score_err' => '',
                'csrf_token_err' => ''
            ];

            // Validate CSRF token
            if ($data['csrf_token'] !== Session::get('csrf_token')) {
                $data['csrf_token_err'] = 'Invalid CSRF token';
            }

            // Validate inputs
            if (empty($data['team_id'])) {
                $data['team_id_err'] = 'Team ID is required';
            }
            if (empty($data['heat_id'])) {
                $data['heat_id_err'] = 'Heat ID is required';
            }
            if (empty($data['score'])) {
                $data['score_err'] = 'Score is required';
            }

            
            if (empty($data['team_id_err']) && empty($data['heat_id_err']) && empty($data['score_err']) && empty($data['csrf_token_err'])) {
                $this->resultModel->addResult([
                    'team_id' => $data['team_id'],
                    'heat_id' => $data['heat_id'],
                    'score' => $data['score']
                ]);

                header('Location: /results');
                exit;
            }

            
            echo $this->view->render('results/create.php', $data);
        } else {
            
            Session::set('csrf_token', bin2hex(random_bytes(32)));

            
            echo $this->view->render('results/create.php', [
                'team_id' => '',
                'heat_id' => '',
                'score' => '',
                'csrf_token' => Session::get('csrf_token')
            ]);
        }
    }
}
