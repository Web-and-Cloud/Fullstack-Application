<?php

declare(strict_types=1);

namespace App\Config;

class Paths
{
  public const VIEW = __DIR__ ."/../views";
}