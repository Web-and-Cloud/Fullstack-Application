<?php

namespace App\Middleware;

use App\Session;

class AuthMiddleware
{
    
    public function handle(callable $next): void
    {
        
        Session::start();

        
        if (!Session::get('user_id') && !Session::get('team_id')) {
           
            header('Location: /login');
            exit;
        }

        
        $next();
    }
}
