<?php

declare(strict_types=1);

namespace App;

class TemplateEngine
{
    private string $viewsPath;

    public function __construct(string $viewsPath)
    {
        $this->viewsPath = rtrim($viewsPath, '/');
    }

    public function render(string $template, array $data = []): string
    {
        $templatePath = $this->viewsPath . '/' . ltrim($template, '/');

        if (!file_exists($templatePath)) {
            throw new \RuntimeException("Template file not found: $templatePath");
        }

        
        extract($data);

        
        ob_start();

        
        include $templatePath;

        
        return ob_get_clean();
    }
}
