<?php

declare(strict_types=1);

namespace App;

class Router
{
    private array $routes = [];

    public function add(string $method, string $path, array $controller): void
    {
        $this->routes[] = [
            'method' => strtoupper($method),
            'path' => rtrim($path, '/'),
            'controller' => $controller,
        ];
    }

    public function dispatch(string $path, string $method): void
    {
        foreach ($this->routes as $route) {
            if ($route['method'] === $method && $route['path'] === rtrim($path, '/')) {
                [$class, $function] = $route['controller'];
                (new $class())->$function();
                return;
            }
        }

        http_response_code(404);
        echo "404 Not Found";
    }
}
