<?php

declare(strict_types=1);

require_once __DIR__ . "/../vendor/autoload.php";

use App\App;
use App\Controllers\HomeController;
use App\Controllers\ResultsController;
use App\Controllers\RegistrationController;
use App\Controllers\UserController;
use App\Controllers\TeamController;
use App\Controllers\HeatController;
use App\Middleware\AuthMiddleware;

$app = new App();

// Home and general routes
$app->get('/', [HomeController::class, 'home']);
$app->get('/about', [HomeController::class, 'about']);

// User-related routes
$app->get('/user/login', [UserController::class, 'login']);
$app->post('/user/login', [UserController::class, 'login']);
$app->get('/user/logout', [UserController::class, 'logout']);

// Team-related routes
$app->get('/team/login', [TeamController::class, 'login']);
$app->post('/team/login', [TeamController::class, 'login']);
$app->get('/team/logout', [TeamController::class, 'logout']);

// Heat-related routes
$app->get('/heats', [HeatController::class, 'index']);
$app->get('/heats/create', [HeatController::class, 'create']);
$app->post('/heats/create', [HeatController::class, 'create']);


// Registration routes
$app->get('/register', [RegistrationController::class, 'create']);
$app->post('/register', [RegistrationController::class, 'store']);

// Results routes
$app->get('/results/create', [ResultsController::class, 'create']);
$app->post('/results/create', [ResultsController::class, 'create']);
$app->get('/results', [ResultsController::class, 'index']);
$app->get('/results/{id}', [ResultsController::class, 'show']);

// Run the application
$app->run();
