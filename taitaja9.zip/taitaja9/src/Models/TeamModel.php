<?php

declare(strict_types=1);

namespace App\Models;

use App\Database;

class TeamModel
{
    private Database $db;

    public function __construct()
    {
        $this->db = new Database();
    }

    /**
     * Create a new team.
     *
     * @param array $formData
     * @return void
     */
    public function createTeam(array $formData): void
    {
        $this->db->query(
            "INSERT INTO teams (team_name, school, members, password)
             VALUES (:team_name, :school, :members, :password)",
            [
                'team_name' => $formData['team_name'],
                'school' => $formData['school'],
                'members' => $formData['members'],
                'password' => password_hash($formData['password'], PASSWORD_BCRYPT, ['cost' => 12])
            ]
        );
    }

    /**
     * Get all teams.
     *
     * @return array
     */
    public function getAllTeams(): array
    {
        return $this->db->query("SELECT * FROM teams")->fetchAll();
    }

    /**
     * Check if a team name already exists.
     *
     * @param string $teamName
     * @return bool
     */
    public function isTeamNameTaken(string $teamName): bool
    {
        $teamCount = $this->db->query(
            "SELECT COUNT(*) 
             FROM teams 
             WHERE team_name = :team_name",
            [
                'team_name' => $teamName
            ]
        )->count();

        return $teamCount > 0;
    }
}
