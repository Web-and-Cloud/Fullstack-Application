<?php

declare(strict_types=1);

namespace App\Models;

use App\Database;

class HeatModel
{
    private Database $db;

    public function __construct()
    {
        $this->db = new Database();
    }

    
    public function createHeat(array $formData): void
    {
        $this->db->query(
            "INSERT INTO heats (name, date)
             VALUES (:name, :date)",
            [
                'name' => $formData['name'],
                'date' => $formData['date']
            ]
        );
    }

    
    public function getAllHeats(): array
    {
        return $this->db->query("SELECT * FROM heats")->fetchAll();
    }

    
    public function getHeatById(int $id): ?array
    {
        return $this->db->query(
            "SELECT * FROM heats WHERE id = :id",
            ['id' => $id]
        )->fetch();
    }
}
