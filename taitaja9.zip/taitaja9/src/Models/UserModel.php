<?php

declare(strict_types=1);

namespace App\Models;

use App\Database;

class UserModel
{
    private Database $db;

    public function __construct()
    {
        $this->db = new Database();
    }

    
    public function createUser(array $formData): bool
    {
        return $this->db->query(
            "INSERT INTO users (name, email, password)
             VALUES (:name, :email, :password)",
            [
                'name' => $formData['name'],
                'email' => $formData['email'],
                'password' => password_hash($formData['password'], PASSWORD_BCRYPT, ['cost' => 12])
            ]
        );
    }

    
    public function findUserByEmail(string $email): ?array
    {
        $result = $this->db->query(
            "SELECT * FROM users WHERE email = :email",
            [
                'email' => $email
            ]
        )->fetch();

        return $result ?: null;
    }

    
    public function authenticateUser(string $email, string $password): ?array
    {
        $user = $this->findUserByEmail($email);

        if ($user && password_verify($password, $user['password'])) {
            return $user;
        }

        return null;
    }

    
    public function isEmailTaken(string $email): bool
    {
        $count = $this->db->query(
            "SELECT COUNT(*) FROM users WHERE email = :email",
            [
                'email' => $email
            ]
        )->count();

        return $count > 0;
    }
}
