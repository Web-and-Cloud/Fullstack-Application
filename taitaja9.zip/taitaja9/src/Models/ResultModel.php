<?php

declare(strict_types=1);

namespace App\Models;

use App\Database;

class ResultModel
{
    private Database $db;

    public function __construct()
    {
        $this->db = new Database();
    }

    /**
     * Add a new result.
     *
     * @param array $formData
     * @return void
     */
    public function addResult(array $formData): void
    {
        $this->db->query(
            "INSERT INTO results (team_id, heat_id, score)
             VALUES (:team_id, :heat_id, :score)",
            [
                'team_id' => $formData['team_id'],
                'heat_id' => $formData['heat_id'],
                'score' => $formData['score']
            ]
        );
    }

    
    public function getAllResults(): array
    {
        return $this->db->query(
            "SELECT results.id, teams.team_name, heats.name AS heat_name, results.score
             FROM results
             JOIN teams ON results.team_id = teams.id
             JOIN heats ON results.heat_id = heats.id
             ORDER BY results.score DESC"
        )->fetchAll();
    }

    
    public function getResultsByTeamId(int $teamId): array
    {
        return $this->db->query(
            "SELECT * FROM results WHERE team_id = :team_id",
            ['team_id' => $teamId]
        )->fetchAll();
    }
}
